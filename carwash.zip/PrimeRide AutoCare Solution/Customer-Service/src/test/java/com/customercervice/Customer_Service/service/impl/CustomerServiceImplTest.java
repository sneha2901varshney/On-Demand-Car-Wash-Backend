package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.CustomerDTO;
import com.customercervice.Customer_Service.entity.Customer;
import com.customercervice.Customer_Service.repository.CustomerRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CustomerServiceImplTest {

    private CustomerRepository customerRepository;
    private CustomerServiceImpl customerService;

    @BeforeEach
    public void setUp() {
        customerRepository = mock(CustomerRepository.class);
        customerService = new CustomerServiceImpl(customerRepository);
    }

    @Test
    public void testRegisterCustomer() {
        CustomerDTO dto = new CustomerDTO(null, "John Doe", "john@example.com", "secret123", "1234567890");
        Customer saved = new Customer(1L, "John Doe", "john@example.com", "secret123", "1234567890");

        when(customerRepository.save(any(Customer.class))).thenReturn(saved);

        CustomerDTO result = customerService.registerCustomer(dto);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("John Doe", result.getFullName());
    }

    @Test
    public void testGetCustomerById_Found() {
        Customer customer = new Customer(1L, "Jane Doe", "jane@example.com", "pass123", "9876543210");

        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));

        CustomerDTO result = customerService.getCustomerById(1L);

        assertEquals("Jane Doe", result.getFullName());
        assertEquals("jane@example.com", result.getEmail());
    }

    @Test
    public void testGetCustomerById_NotFound() {
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> customerService.getCustomerById(1L));
    }

    @Test
    public void testGetAllCustomers() {
        List<Customer> customers = Arrays.asList(
                new Customer(1L, "John", "john@mail.com", "pass", "111"),
                new Customer(2L, "Jane", "jane@mail.com", "word", "222")
        );

        when(customerRepository.findAll()).thenReturn(customers);

        List<CustomerDTO> result = customerService.getAllCustomers();

        assertEquals(2, result.size());
        assertEquals("John", result.get(0).getFullName());
    }

    @Test
    public void testUpdateCustomer_Success() {
        Customer existing = new Customer(1L, "Old Name", "old@mail.com", "pass", "111");
        Customer updated = new Customer(1L, "New Name", "old@mail.com", "pass", "999");

        CustomerDTO updateDTO = new CustomerDTO(null, "New Name", "old@mail.com", "pass", "999");

        when(customerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(customerRepository.save(any(Customer.class))).thenReturn(updated);

        CustomerDTO result = customerService.updateCustomer(1L, updateDTO);

        assertEquals("New Name", result.getFullName());
        assertEquals("999", result.getPhone());
    }

    @Test
    public void testUpdateCustomer_NotFound() {
        CustomerDTO dto = new CustomerDTO(null, "Test", "test@mail.com", "pass", "123");
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> customerService.updateCustomer(1L, dto));
    }

    @Test
    public void testDeleteCustomer_Success() {
        when(customerRepository.existsById(1L)).thenReturn(true);
        doNothing().when(customerRepository).deleteById(1L);

        assertDoesNotThrow(() -> customerService.deleteCustomer(1L));
        verify(customerRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteCustomer_NotFound() {
        when(customerRepository.existsById(1L)).thenReturn(false);

        assertThrows(EntityNotFoundException.class, () -> customerService.deleteCustomer(1L));
    }
}
