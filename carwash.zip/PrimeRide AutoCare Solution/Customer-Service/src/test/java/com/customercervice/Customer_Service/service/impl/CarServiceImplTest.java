package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.CarDTO;
import com.customercervice.Customer_Service.entity.Car;
import com.customercervice.Customer_Service.entity.Customer;
import com.customercervice.Customer_Service.repository.CarRepository;
import com.customercervice.Customer_Service.repository.CustomerRepository;
import com.customercervice.Customer_Service.service.CarService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CarServiceImplTest {

    private CarRepository carRepository;
    private CustomerRepository customerRepository;
    private CarService carService;

    @BeforeEach
    public void setUp() {
        carRepository = mock(CarRepository.class);
        customerRepository = mock(CustomerRepository.class);
        carService = new CarServiceImpl(carRepository, customerRepository);
    }

    @Test
    public void testAddCar() {
        // Create a CarDTO to pass
        CarDTO dto = new CarDTO(null, "Toyota", "Camry", "White", "ABC-123", 1L);

        // Mock a customer
        Customer customer = new Customer(1L, "John Doe", "john@example.com", "pass", "1234567890");

        // Mock repository behavior
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(carRepository.save(any(Car.class))).thenAnswer(invocation -> {
            Car car = invocation.getArgument(0);
            car.setId(1L); // simulate DB-generated ID
            return car;
        });

        // Call the service method
        CarDTO result = carService.addCar(dto);

        // Assertions
        assertNotNull(result);
        assertEquals("Toyota", result.getBrand());
        assertEquals("Camry", result.getModel());
        assertEquals("White", result.getColor());
        assertEquals("ABC-123", result.getLicensePlate());
        assertEquals(1L, result.getCustomerId());
    }

    @Test
    public void testUpdateCar() {
        // Existing car and customer
        Customer customer = new Customer(1L, "Alice Smith", "alice@example.com", "securepass", "9876543210");
        Car existingCar = new Car(1L, "Ford", "Focus", "Grey", "XYZ-789");
        existingCar.setCustomer(customer);

        CarDTO updateDto = new CarDTO(null, "Ford", "Fiesta", "Red", "XYZ-789", 1L);

        when(carRepository.findById(1L)).thenReturn(Optional.of(existingCar));
        when(carRepository.save(any(Car.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CarDTO updated = carService.updateCar(1L, updateDto);

        assertEquals("Ford", updated.getBrand());
        assertEquals("Fiesta", updated.getModel());
        assertEquals("Red", updated.getColor());
        assertEquals("XYZ-789", updated.getLicensePlate());
    }
}
