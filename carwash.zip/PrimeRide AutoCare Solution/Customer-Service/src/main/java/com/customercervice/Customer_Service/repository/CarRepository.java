package com.customercervice.Customer_Service.repository;

import com.customercervice.Customer_Service.entity.Car;
import com.customercervice.Customer_Service.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {

    // Find cars by customer
    List<Car> findByCustomer(Customer customer);
}
