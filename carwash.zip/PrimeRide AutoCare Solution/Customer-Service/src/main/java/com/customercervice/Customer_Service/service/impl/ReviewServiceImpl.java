package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.ReviewDTO;
import com.customercervice.Customer_Service.entity.Review;
import com.customercervice.Customer_Service.repository.ReviewRepository;
import com.customercervice.Customer_Service.service.ReviewService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public ReviewDTO submitReview(ReviewDTO reviewDTO) {
        Review review = new Review();
        review.setCustomerId(reviewDTO.getCustomerId());
        review.setWasherId(reviewDTO.getWasherId());
        review.setRating(reviewDTO.getRating());
        review.setComment(reviewDTO.getComment());
        review.setCreatedAt(LocalDateTime.now());

        Review savedReview = reviewRepository.save(review);
        return convertToDTO(savedReview);
    }

    @Override
    public List<ReviewDTO> getReviewsByCustomerId(Long customerId) {
        log.info("Fetching Reviews given by customer ID: {}", customerId);
        List<Review> reviews = reviewRepository.findByCustomerId(customerId);
        log.info("Successfully fetched Reviews given by customer ID: {}", customerId);
        return reviews.stream().map(this::convertToDTO).collect(Collectors.toList());

    }

    public List<ReviewDTO> getReviewsByWasherId(Long washerId) {
        List<Review> reviews = reviewRepository.findByWasherId(washerId);
        return reviews.stream().map(this::convertToDTO).collect(Collectors.toList());
    }


    public List<ReviewDTO> getAllWasherReviews() {
        List<Review> reviews = reviewRepository.findByWasherIdIsNotNull();
        return reviews.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }


    private ReviewDTO convertToDTO(Review review) {
        return new ReviewDTO(
                review.getId(),
                review.getCustomerId(),
                review.getWasherId(),
                review.getRating(),
                review.getComment()
        );
    }
}
