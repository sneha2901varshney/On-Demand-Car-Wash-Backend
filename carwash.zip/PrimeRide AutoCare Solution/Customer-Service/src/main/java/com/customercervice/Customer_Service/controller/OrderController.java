package com.customercervice.Customer_Service.controller;


import com.customercervice.Customer_Service.dto.OrderDTO;
import com.customercervice.Customer_Service.service.OrderService;
import com.customercervice.Customer_Service.service.impl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderServiceImpl orderServiceImpl;

    // Get current orders for a customer
    @GetMapping("/current/{customerId}")
    public ResponseEntity<List<OrderDTO>> getCurrentOrders(@PathVariable Long customerId) {
        List<OrderDTO> orders = orderServiceImpl.getCurrentOrders(customerId);
        return ResponseEntity.ok(orders);
    }

    // Get past orders for a customer
    @GetMapping("/past/{customerId}")
    public ResponseEntity<List<OrderDTO>> getPastOrders(@PathVariable Long customerId) {
        List<OrderDTO> orders = orderServiceImpl.getPastOrders(customerId);
        return ResponseEntity.ok(orders);
    }

    @PostMapping("/create")
    public ResponseEntity<OrderDTO> create(@RequestBody OrderDTO orderDTO) {
        return ResponseEntity.ok(orderServiceImpl.
                createOrder(orderDTO));
    }
}
