package com.customercervice.Customer_Service.dto;

import lombok.*;

import java.time.LocalDate;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;
    private Long customerId;
    private Long washerId;
    private String carModel;
    private String carNumber;
    private String carName;
    private String packageName;
    private String addOns;
    private String status;
    private LocalDate washDate;
    private LocalDate scheduleDate;
    private String location;



}
