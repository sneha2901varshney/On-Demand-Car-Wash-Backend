package com.customercervice.Customer_Service.service.impl;


import com.customercervice.Customer_Service.client.OrderClient;

import com.customercervice.Customer_Service.dto.OrderDTO;
import com.customercervice.Customer_Service.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderClient orderClient;


    @Override
    public List<OrderDTO> getCurrentOrders(Long customerId) {
        log.info("Fetching current orders for customer ID: {}", customerId);
        List<OrderDTO> currentOrders = orderClient.getCurrentOrders(customerId);
        log.info("Successfully fetched {} current orders for customer ID: {}", currentOrders.size(), customerId);
        return currentOrders;
    }


    @Override
    public List<OrderDTO> getPastOrders(Long customerId) {

        return orderClient.getPastOrders(customerId);
    }

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        return orderClient.createOrder(orderDTO);
    }
}
