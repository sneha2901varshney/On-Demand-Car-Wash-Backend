package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.CarDTO;
import com.customercervice.Customer_Service.entity.Car;
import com.customercervice.Customer_Service.entity.Customer;
import com.customercervice.Customer_Service.repository.CarRepository;
import com.customercervice.Customer_Service.repository.CustomerRepository;
import com.customercervice.Customer_Service.service.CarService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;

    @Autowired
    public CarServiceImpl(CarRepository carRepository, CustomerRepository customerRepository) {
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public CarDTO addCar(CarDTO carDTO) {
        // Fetch the Customer entity using customerId from DTO
        Customer customer = customerRepository.findById(carDTO.getCustomerId())
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with ID: " + carDTO.getCustomerId()));

        // Convert DTO to Entity
        Car car = new Car();
        car.setBrand(carDTO.getBrand());
        car.setModel(carDTO.getModel());
        car.setColor(carDTO.getColor());
        car.setLicensePlate(carDTO.getLicensePlate());
        car.setCustomer(customer); // Setting full Customer entity (required by @ManyToOne)

        Car savedCar = carRepository.save(car);

        // Return DTO with generated ID
        return new CarDTO(
                savedCar.getId(),
                savedCar.getBrand(),
                savedCar.getModel(),
                savedCar.getColor(),
                savedCar.getLicensePlate(),
                customer.getId()
        );
    }

    @Override
    public List<CarDTO> getCarsByCustomerId(Long customerId) {
        // Check if customer exists
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with ID: " + customerId));

        // Fetch all cars for the given customer
        List<Car> cars = carRepository.findByCustomer(customer);

        // Convert each Car entity to CarDTO
        return cars.stream().map(car -> new CarDTO(
                car.getId(),
                car.getBrand(),
                car.getModel(),
                car.getColor(),
                car.getLicensePlate(),
                customerId
        )).collect(Collectors.toList());
    }

    @Override
    public CarDTO updateCar(Long id, CarDTO carDTO) {
        // Find existing car
        Car car = carRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Car not found with ID: " + id));

        // Update car fields
        car.setBrand(carDTO.getBrand());
        car.setModel(carDTO.getModel());
        car.setColor(carDTO.getColor());
        car.setLicensePlate(carDTO.getLicensePlate());

        Car updatedCar = carRepository.save(car);

        // Return updated DTO
        return new CarDTO(
                updatedCar.getId(),
                updatedCar.getBrand(),
                updatedCar.getModel(),
                updatedCar.getColor(),
                updatedCar.getLicensePlate(),
                updatedCar.getCustomer().getId()
        );
    }

    @Override
    public void deleteCar(Long id) {
        if (!carRepository.existsById(id)) {
            throw new EntityNotFoundException("Car not found with ID: " + id);
        }
        carRepository.deleteById(id);
    }
}
