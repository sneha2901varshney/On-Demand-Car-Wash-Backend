package com.customercervice.Customer_Service.controller;

import com.customercervice.Customer_Service.dto.CarDTO;
import com.customercervice.Customer_Service.service.CarService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller to manage car operations for customers
 */
@RestController
@RequestMapping("/api/cars")
public class CarController {

    private final CarService carService;

    // Constructor injection
    @Autowired
    public CarController(CarService carService) {
        this.carService = carService;
    }

    // Add a new car
    @PostMapping
    public ResponseEntity<CarDTO> addCar(@Valid @RequestBody CarDTO carDTO) {
        return ResponseEntity.ok(carService.addCar(carDTO));
    }

    // Get all cars for a specific customer
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<CarDTO>> getCarsByCustomerId(@PathVariable Long customerId) {
        return ResponseEntity.ok(carService.getCarsByCustomerId(customerId));
    }

    // Update a car
    @PutMapping("/{id}")
    public ResponseEntity<CarDTO> updateCar(@PathVariable Long id,
                                            @Valid @RequestBody CarDTO carDTO) {
        return ResponseEntity.ok(carService.updateCar(id, carDTO));
    }

    // Delete a car
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
        return ResponseEntity.noContent().build();
    }
}
