package com.customercervice.Customer_Service.client;

import com.customercervice.Customer_Service.dto.OrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "ORDER-SERVICE")
public interface OrderClient {

    @GetMapping("/api/orders/current/{customerId}")
    List<OrderDTO> getCurrentOrders(@PathVariable("customerId") Long customerId);

    @GetMapping("/api/orders/past/{customerId}")
    List<OrderDTO> getPastOrders(@PathVariable("customerId") Long customerId);

    @PostMapping("/api/orders/create")
    OrderDTO createOrder(OrderDTO orderDTO);
}
