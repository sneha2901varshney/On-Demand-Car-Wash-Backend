package com.customercervice.Customer_Service.service;


import com.customercervice.Customer_Service.dto.OrderDTO;

import java.util.List;

public interface OrderService {
    List<OrderDTO> getCurrentOrders(Long customerId);
    List<OrderDTO> getPastOrders(Long customerId);
    OrderDTO createOrder(OrderDTO orderDTO);
}
