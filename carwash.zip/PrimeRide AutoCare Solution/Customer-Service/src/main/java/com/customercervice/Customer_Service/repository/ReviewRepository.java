package com.customercervice.Customer_Service.repository;


import com.customercervice.Customer_Service.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByCustomerId(Long customerId);
    List<Review> findByWasherId(Long washerId);
    List<Review> findByWasherIdIsNotNull();


}
