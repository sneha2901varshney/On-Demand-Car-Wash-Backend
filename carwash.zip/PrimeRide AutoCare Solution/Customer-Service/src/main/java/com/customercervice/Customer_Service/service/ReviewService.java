package com.customercervice.Customer_Service.service;

import com.customercervice.Customer_Service.dto.ReviewDTO;

import java.util.List;

public interface ReviewService {
    ReviewDTO submitReview(ReviewDTO reviewDTO);
    List<ReviewDTO> getReviewsByCustomerId(Long customerId);
}
