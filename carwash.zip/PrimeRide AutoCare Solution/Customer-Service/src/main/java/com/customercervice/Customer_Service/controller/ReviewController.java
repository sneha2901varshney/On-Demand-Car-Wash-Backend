package com.customercervice.Customer_Service.controller;


import com.customercervice.Customer_Service.dto.ReviewDTO;
import com.customercervice.Customer_Service.service.impl.ReviewServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewServiceImpl reviewService;

    // Get all reviews for all washers
    @GetMapping("/washer")
    public ResponseEntity<List<ReviewDTO>> getAllWasherReviews() {
        List<ReviewDTO> reviews = reviewService.getAllWasherReviews();
        return ResponseEntity.ok(reviews);
    }


    // Submit a review
    @PostMapping
    public ResponseEntity<ReviewDTO> submitReview(@Valid @RequestBody ReviewDTO reviewDTO) {
        ReviewDTO savedReview = reviewService.submitReview(reviewDTO);
        return ResponseEntity.ok(savedReview);
    }

    // Get all reviews submitted by a specific customer
    @GetMapping("/{customerId}")
    public ResponseEntity<List<ReviewDTO>> getReviewsByCustomer(@PathVariable Long customerId) {
        List<ReviewDTO> reviews = reviewService.getReviewsByCustomerId(customerId);
        return ResponseEntity.ok(reviews);
    }

    // Get all reviews submitted for a specific washer
    @GetMapping("/washer/{washerId}")
    public ResponseEntity<List<ReviewDTO>> getReviewsByWasher(@PathVariable Long washerId) {
        List<ReviewDTO> reviews = reviewService.getReviewsByWasherId(washerId);
        return ResponseEntity.ok(reviews);
    }

}
