package com.customercervice.Customer_Service.service;

import com.customercervice.Customer_Service.dto.CarDTO;

import java.util.List;

public interface CarService {

    CarDTO addCar(CarDTO carDTO);

    List<CarDTO> getCarsByCustomerId(Long customerId);

    CarDTO updateCar(Long id, CarDTO carDTO);

    void deleteCar(Long id);
}
