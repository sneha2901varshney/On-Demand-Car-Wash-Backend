package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.CarDTO;
import com.customercervice.Customer_Service.dto.CustomerDTO;
import com.customercervice.Customer_Service.entity.Customer;
import com.customercervice.Customer_Service.repository.CustomerRepository;
import com.customercervice.Customer_Service.service.CustomerService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    // Constructor injection
    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public CustomerDTO registerCustomer(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        customer.setFullName(customerDTO.getFullName());
        customer.setEmail(customerDTO.getEmail());
        customer.setPassword(customerDTO.getPassword());
        customer.setPhone(customerDTO.getPhone());

        Customer saved = customerRepository.save(customer);



        customerDTO.setId(saved.getId());
        return customerDTO;
    }

    @Override
    public CustomerDTO getCustomerById(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found"));

        List<CarDTO> carDTOs = customer.getCars().stream().map(car -> new CarDTO(
                car.getId(),
                car.getBrand(),
                car.getModel(),
                car.getColor(),
                car.getLicensePlate(),
                customer.getId()
        )).collect(Collectors.toList());

        return new CustomerDTO(
                customer.getId(),
                customer.getFullName(),
                customer.getEmail(),
                customer.getPassword(),
                customer.getPhone(),
                carDTOs
        );
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {
        log.info("Fetching all customers");
        CustomerDTO cdto = new CustomerDTO();
        List<Customer> customers = customerRepository.findAll();
        List<CustomerDTO> dtos = new ArrayList<>();
        for (Customer customer : customers) {
            List<CarDTO> carDTOs = customer.getCars().stream().map(car -> new CarDTO(
                    car.getId(),
                    car.getBrand(),
                    car.getModel(),
                    car.getColor(),
                    car.getLicensePlate(),
                    customer.getId()
            )).collect(Collectors.toList());

            dtos.add(new CustomerDTO(
                    customer.getId(),
                    customer.getFullName(),
                    customer.getEmail(),
                    customer.getPassword(),
                    customer.getPhone(),
                    carDTOs
            ));
        }


        log.info("Successfully fetched {} customers", dtos.size());
        return dtos;
    }

    @Override
    public CustomerDTO updateCustomer(Long id, CustomerDTO customerDTO) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found"));

        customer.setFullName(customerDTO.getFullName());
        customer.setPhone(customerDTO.getPhone());

        Customer updated = customerRepository.save(customer);

        CustomerDTO cdto = new CustomerDTO();
        cdto.setId(updated.getId());
        cdto.setFullName(updated.getFullName());
        cdto.setPhone(updated.getPhone());
        cdto.setEmail(updated.getEmail());
        cdto.setPassword(updated.getPassword());
        List<CarDTO> carDTOs = updated.getCars().stream().map(car -> new CarDTO(
                car.getId(),
                car.getBrand(),
                car.getModel(),
                car.getColor(),
                car.getLicensePlate(),
                customer.getId()
        )).collect(Collectors.toList());
        cdto.setCars(carDTOs);

        return cdto;


    }

    @Override
    public void deleteCustomer(Long id) {
        if (!customerRepository.existsById(id)) {
            throw new EntityNotFoundException("Customer not found");
        }
        customerRepository.deleteById(id);
    }
}
