package com.gateway.APIGateway.filter;

import com.gateway.APIGateway.util.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import reactor.core.publisher.Mono;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class JwtAuthenticationFilter implements GlobalFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

       //Request handling
        ServerHttpRequest request = exchange.getRequest();

        System.out.println("Request URI: " + request.getURI().getPath());



        if (request.getURI().getPath().contains("/auth") || request.getURI().getPath().contains("/api/payments")) {
            System.out.println("Skipping auth route");
            return chain.filter(exchange); // Skip auth route
        }

        String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        System.out.println("Authorization Header: " + authHeader);

        //Authorization Header Validation
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            System.out.println("Invalid Authorization Header");
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        String token = authHeader.substring(7);
        System.out.println("Token: " + token);

        if (!jwtUtil.validateToken(token)) {
            System.out.println("Invalid Token");
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        Claims claims = jwtUtil.extractClaims(token);
        String role = claims.get("role", String.class);
        String path = request.getPath().toString();

        System.out.println("Role: " + role);
        System.out.println("Path: " + path);

        // Role-based routing checks
        if ((path.startsWith("/api/admin") && !"ADMIN".equals(role)) ||
                (path.startsWith("/api/customers") && !"CUSTOMER".equals(role)) ||
                (path.startsWith("/api/washers") && !"WASHER".equals(role))) {

            System.out.println("Forbidden: Role does not match path");
            exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
            return exchange.getResponse().setComplete();
        }

        return chain.filter(exchange);
    }
}
