package com.gateway.APIGateway.util;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

    @Value("${jwt.secret}") //inject the value of the jwt.secret property from the application's configuration file
    private String secret;

    public Claims extractClaims(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
    }

    public String extractRole(String token) {
        return extractClaims(token).get("role", String.class);
    }

    public boolean validateToken(String token) {
        try{
            Jwts.parser() // Creates a new JWT parser
                    .setSigningKey(secret) //Sets the secret key for verifying the token's signature.
                    .parseClaimsJws(token) //Parses the token and verifies its signature.
                    .getBody(); // Retrieves the claims from the token.
            return true;
        } catch (Exception e) {
            return false;
        }

    }
}

