package com.carwash.payment_service.dto;


import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class PaymentRequest {


    private String orderId;
    private String customerId;


    // Getters and Setters
}

