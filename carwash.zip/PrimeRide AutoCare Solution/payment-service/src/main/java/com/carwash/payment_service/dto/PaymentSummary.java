package com.carwash.payment_service.dto;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PaymentSummary {
    private Double amount;
    private String currency;
    private String customerId;
    private String packageName;
    private LocalDateTime createdAt;


    public PaymentSummary(Double amount, String currency, String customerId, String packageName,LocalDateTime createdAt) {
        this.amount = amount;
        this.currency = currency;
        this.customerId = customerId;
        this.packageName=packageName;
        this.createdAt = createdAt;
    }


    // Getters and Setters
}

