package com.carwash.payment_service.controller;


import com.carwash.payment_service.dto.PaymentRequest;
import com.carwash.payment_service.dto.PaymentResponse;
import com.carwash.payment_service.dto.PaymentSummary;
import com.carwash.payment_service.entity.PaymentInfo;
import com.carwash.payment_service.service.PaymentServiceImpl;
import jakarta.ws.rs.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/payments")
@CrossOrigin("*")
public class PaymentController {


    @Autowired
    private PaymentServiceImpl paymentServiceImpl;




    @PostMapping("/create-payment-intent")
    public PaymentResponse createPaymentIntent(@RequestBody PaymentRequest request) {
        return paymentServiceImpl.createPaymentIntent(request);
    }

    @GetMapping("/all")
    public List<PaymentSummary> getAllPayments() {
        return paymentServiceImpl.getAllPaymentSummaries();
    }


    @GetMapping("/payment-success")
    public ResponseEntity<PaymentInfo> getPaymentBySessionId(@RequestParam("session_id") String sessionId) {
        PaymentInfo payment = paymentServiceImpl.getPaymentBySessionId(sessionId);
        return ResponseEntity.ok(payment);
    }





}

