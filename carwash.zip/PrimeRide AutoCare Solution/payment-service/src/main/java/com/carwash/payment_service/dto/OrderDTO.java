package com.carwash.payment_service.dto;


import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotNull(message = "Washer ID is required")
    private Long washerId;

    @NotBlank(message = "Car details are required")
    private String carDetails;

//    @NotBlank(message = "Status is required")
//    private String status;

    private LocalDateTime scheduledTime;

    @NotNull(message = "Package name is required")
    private String packageName;

    @FutureOrPresent(message = "Schedule date cannot be in the past")
    private LocalDate scheduleDate;

    @NotBlank(message = "Location is required")
    private String location;

    private String paymentStatus;

    private Double price;


}
