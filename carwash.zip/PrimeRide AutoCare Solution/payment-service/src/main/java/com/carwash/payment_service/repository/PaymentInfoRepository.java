package com.carwash.payment_service.repository;

import com.carwash.payment_service.entity.PaymentInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface PaymentInfoRepository extends JpaRepository<PaymentInfo, Long> {

    Optional<PaymentInfo> findBySessionId(String sessionId);
}

