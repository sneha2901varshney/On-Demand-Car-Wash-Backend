package com.carwash.payment_service.service;


import com.carwash.payment_service.client.OrderClient;
import com.carwash.payment_service.dto.OrderDTO;
import com.carwash.payment_service.dto.PaymentRequest;
import com.carwash.payment_service.dto.PaymentResponse;
import com.carwash.payment_service.dto.PaymentSummary;
import com.carwash.payment_service.entity.PaymentInfo;
import com.carwash.payment_service.repository.PaymentInfoRepository;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class PaymentServiceImpl {

    @Autowired
    private  PaymentInfoRepository paymentRepository;

    @Autowired
    private  OrderClient orderClient;


    @Value("${stripe.api.key}")
    private String stripeSecretKey;


    @PostConstruct
    public void init() {
        Stripe.apiKey = stripeSecretKey;
    }





    public PaymentResponse createPaymentIntent(PaymentRequest request) {
        // Step 1: Fetch order from Order Service
        OrderDTO order = orderClient.getOrderById(Long.parseLong(request.getOrderId()));


        if (!order.getPaymentStatus().equalsIgnoreCase("PENDING")) {
            throw new RuntimeException("Order payment is already completed or invalid.");
        }


        // Step 2: Create Stripe Checkout Session
        SessionCreateParams.LineItem.PriceData.ProductData productData =
                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                        .setName("Customer Id - " + order.getCustomerId())
                        .setDescription("Payment for booking Car Wash Package")
                        .build();


        SessionCreateParams.LineItem.PriceData priceData =
                SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency("INR")
                        .setUnitAmount((long) (order.getPrice()*100)) // Replace with actual order amount * 100
                        .setProductData(productData)
                        .build();


        SessionCreateParams.LineItem lineItem =
                SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPriceData(priceData)
                        .build();


        SessionCreateParams params = SessionCreateParams.builder()
                .addLineItem(lineItem)
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:8085/api/payments/payment-success?session_id={CHECKOUT_SESSION_ID}")
                .setCancelUrl("http://localhost:3000/payment-cancel")
                .setCustomerEmail("customer@example.com") // replace with dynamic if available
                .build();


        try {
            Session session = Session.create(params);


            // Step 3: Save Payment Info
            PaymentInfo payment = new PaymentInfo();
            payment.setCustomerId(request.getCustomerId());
            payment.setOrderId(request.getOrderId());
            payment.setAmount(order.getPrice()); // Replace with actual order.getAmount()
            payment.setCurrency("INR");
            payment.setPackageName(order.getPackageName());
            payment.setPaymentIntentId(session.getPaymentIntent());
            payment.setSessionId(session.getId());
            payment.setSessionUrl(session.getUrl());
            payment.setPaymentStatus(order.getPaymentStatus());
            payment.setCreatedAt(LocalDateTime.now());
            paymentRepository.save(payment);


            return new PaymentResponse(session.getUrl());
        } catch (Exception e) {
            throw new RuntimeException("Error creating Stripe session: " + e.getMessage(), e);
        }
    }


    public List<PaymentSummary> getAllPaymentSummaries() {
        List<PaymentInfo> payments = paymentRepository.findAll();
        return payments.stream()
                .map(payment -> new PaymentSummary(
                        payment.getAmount(),
                        payment.getCurrency(),
                        payment.getCustomerId(),
                        payment.getPackageName(),
                        payment.getCreatedAt()
                ))
                .collect(Collectors.toList());
    }

    public PaymentInfo getPaymentBySessionId(String sessionId) {
        PaymentInfo payment = paymentRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new RuntimeException("Payment not found for session ID: " + sessionId));
                payment.setPaymentStatus("ACCEPTED");
                return paymentRepository.save(payment);
    }


}

