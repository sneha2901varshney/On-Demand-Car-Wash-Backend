package com.orderservice.Order_Service.dto;

import com.orderservice.Order_Service.enums.PackageType;
import com.orderservice.Order_Service.enums.PaymentStatus;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotNull(message = "Washer ID is required")
    private Long washerId;

    @NotBlank(message = "Car model is required")
    private String carModel;

    @NotBlank(message = "Car number is required")
    private String carNumber;

    @NotBlank(message = "Car name is required")
    private String carName;


    @NotNull(message = "Package name is required")
    private PackageType packageName;


    private String addOns;

    @NotBlank(message = "Order status is required")
    private String status;

    @FutureOrPresent(message = "Wash date cannot be in the past")
    private LocalDate washDate;

    @FutureOrPresent(message = "Schedule date cannot be in the past")
    private LocalDate scheduleDate;

    @NotBlank(message = "Location is required")
    private String location;

    @NotNull(message = "Payment Status is required")
    private PaymentStatus paymentStatus;

    private Double price;



}
