package com.orderservice.Order_Service.service;

import com.orderservice.Order_Service.dto.OrderDTO;

// OrderService.java

import com.orderservice.Order_Service.dto.OrderDTO;

import java.util.List;

public interface OrderService {
    OrderDTO createOrder(OrderDTO orderDTO);
    OrderDTO getOrderById(Long id);
    List<OrderDTO> getAllOrders();
    List<OrderDTO> getOrdersByCustomerId(Long customerId);
    List<OrderDTO> getOrdersByWasherId(Long washerId);
    OrderDTO updateOrder(Long id, OrderDTO orderDTO);
    void deleteOrder(Long id);
    OrderDTO updateOrderStatus(Long orderId, String status);

    List<OrderDTO> getCurrentOrders(Long customerId);

    List<OrderDTO> getPastOrders(Long customerId);
}
