package com.orderservice.Order_Service.enums;

public enum PackageType {


    BASIC,
    DELUXE,
    PREMIUM,

}
