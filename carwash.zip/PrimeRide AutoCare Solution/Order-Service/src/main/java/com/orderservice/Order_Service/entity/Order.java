package com.orderservice.Order_Service.entity;

import com.orderservice.Order_Service.enums.PaymentStatus;
import jakarta.persistence.*;
import java.time.LocalDate;
import com.orderservice.Order_Service.enums.PackageType;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long customerId;
    private Long washerId;
    private String carModel;
    private String carNumber;
    private String carName;

    @Enumerated(EnumType.STRING)
    private PackageType packageName;

    private String addOns;
    private String status;
    private LocalDate washDate;
    private LocalDate scheduleDate;
    private String location;

    private Double price;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;



    public void setPriceBasedOnPackage() {
        switch (this.packageName) {
            case BASIC:
                this.price = 500.0;
                break;
            case DELUXE:
                this.price = 1000.0;
                break;
            case PREMIUM:
                this.price = 1500.0;
                break;
            default:
                this.price = 0.0;
                break;
        }
    }




}
