package com.orderservice.Order_Service.service.impl;

import com.orderservice.Order_Service.dto.OrderDTO;
import com.orderservice.Order_Service.entity.Order;
import com.orderservice.Order_Service.enums.PaymentStatus;
import com.orderservice.Order_Service.repository.OrderRepository;
import com.orderservice.Order_Service.service.OrderService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


//@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);
    @Autowired
    private OrderRepository orderRepository;

    private OrderDTO mapToDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setCustomerId(order.getCustomerId());
        dto.setWasherId(order.getWasherId());
        dto.setCarModel(order.getCarModel());
        dto.setCarNumber(order.getCarNumber());
        dto.setCarName(order.getCarName());
        dto.setPackageName(order.getPackageName());
        dto.setAddOns(order.getAddOns());
        dto.setStatus(order.getStatus());
        dto.setWashDate(order.getWashDate());
        dto.setScheduleDate(order.getScheduleDate());
        dto.setLocation(order.getLocation());
        dto.setPaymentStatus(order.getPaymentStatus());
//        order.setPriceBasedOnPackage();
        dto.setPrice(order.getPrice());
        return dto;
    }

    private Order mapToEntity(OrderDTO dto) {
        Order order = new Order();
        order.setId(dto.getId());
        order.setCustomerId(dto.getCustomerId());
        order.setWasherId(dto.getWasherId());
        order.setCarModel(dto.getCarModel());
        order.setCarNumber(dto.getCarNumber());
        order.setCarName(dto.getCarName());
        order.setPackageName(dto.getPackageName());
        order.setAddOns(dto.getAddOns());
        order.setStatus(dto.getStatus());
        order.setWashDate(dto.getWashDate());
        order.setScheduleDate(dto.getScheduleDate());
        order.setLocation(dto.getLocation());
        order.setPriceBasedOnPackage();
        order.setPaymentStatus(PaymentStatus.PENDING);
        return order;
    }

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        Order savedOrder = orderRepository.save(mapToEntity(orderDTO));
        return mapToDTO(savedOrder);
    }

    @Override
    public OrderDTO getOrderById(Long id) {
        Optional<Order> order = orderRepository.findById(id);
        return order.map(this::mapToDTO).orElse(null);
    }

    @Override
    public List<OrderDTO> getAllOrders() {

        log.info("Entering getAllOrders method");

        List<OrderDTO> orders = orderRepository.findAll()
                .stream().map(this::mapToDTO)
                .collect(Collectors.toList());


        log.info("Fetched {} orders", orders.size());
        log.debug("Order details: {}", orders);

        log.info("Exiting getAllOrders method");

        return orders;
    }

    @Override
    public List<OrderDTO> getOrdersByCustomerId(Long customerId) {
        return orderRepository.findByCustomerId(customerId)
                .stream().map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> getOrdersByWasherId(Long washerId) {
        return orderRepository.findByWasherId(washerId)
                .stream().map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO updateOrder(Long id, OrderDTO orderDTO) {
        Optional<Order> existing = orderRepository.findById(id);
        if (existing.isPresent()) {
            Order updated = mapToEntity(orderDTO);
            updated.setId(id);
            return mapToDTO(orderRepository.save(updated));
        }
        return null;
    }

    @Override
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    @Override
    public OrderDTO updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new EntityNotFoundException("Order not found with ID: " + orderId));
        order.setStatus(status);

        return mapToDTO(orderRepository.save(order));
    }

    @Override
    public List<OrderDTO> getCurrentOrders(Long customerId) {
        // Implement logic to fetch current orders for the customer
        // This is a placeholder implementation
        return orderRepository.findByCustomerIdAndStatus(customerId, "Pending")
                .stream().map(this::mapToDTO) .collect(Collectors.toList());
    }
    @Override
    public List<OrderDTO> getPastOrders(Long customerId) {
        // Implement logic to fetch past orders for the customer
        // This is a placeholder implementation
        return orderRepository.findByCustomerIdAndStatusNot(customerId, "Pending")
                .stream().map(this::mapToDTO) .collect(Collectors.toList());
    }
}

