package com.orderservice.Order_Service.controller;

import com.orderservice.Order_Service.dto.OrderDTO;
import com.orderservice.Order_Service.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public ResponseEntity<OrderDTO> create(@Valid @RequestBody OrderDTO orderDTO) {
        return ResponseEntity.ok(orderService.createOrder(orderDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<OrderDTO>> getAll() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<OrderDTO>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(orderService.getOrdersByCustomerId(customerId));
    }

    @GetMapping("/washer/{washerId}")
    public ResponseEntity<List<OrderDTO>> getByWasher(@PathVariable Long washerId) {
        return ResponseEntity.ok(orderService.getOrdersByWasherId(washerId));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<OrderDTO> update(@PathVariable Long id, @RequestBody OrderDTO orderDTO) {
        return ResponseEntity.ok(orderService.updateOrder(id, orderDTO));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok("Order deleted successfully.");
    }

    @PutMapping("/status/{id}")
    public ResponseEntity<OrderDTO> updateStatus(
            @PathVariable Long id,
            @RequestParam String status
    ) {
        return ResponseEntity.ok(orderService.updateOrderStatus(id, status));
    }

    @GetMapping("/current/{customerId}")
    public ResponseEntity<List<OrderDTO>> getCurrentOrders(@PathVariable Long customerId){
        List<OrderDTO> orders = orderService
                .getCurrentOrders(customerId);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/past/{customerId}")
    public ResponseEntity<List<OrderDTO>> getPastOrders(@PathVariable Long customerId){
        List<OrderDTO> orders = orderService
                .getPastOrders(customerId);
        return ResponseEntity.ok(orders);
    }

}
