package com.orderservice.Order_Service.enums;

public enum PaymentStatus {
    PENDING,
    ACCEPTED,
    FAILED
}
