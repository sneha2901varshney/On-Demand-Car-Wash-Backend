package com.orderservice.Order_Service.service;

import com.orderservice.Order_Service.dto.OrderDTO;
import com.orderservice.Order_Service.entity.Order;
import com.orderservice.Order_Service.enums.PackageType;
import com.orderservice.Order_Service.enums.PaymentStatus;
import com.orderservice.Order_Service.repository.OrderRepository;
import com.orderservice.Order_Service.service.impl.OrderServiceImpl;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderServiceImplTest {

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderServiceImpl orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private Order createSampleOrder() {
        return new Order(1L, 101L, 201L, "Model S", "MH12AB1234", "Tesla",
                PackageType.PREMIUM, "Wax", "Pending",
                LocalDate.now().plusDays(1), LocalDate.now().plusDays(2),
                "Mumbai", 1500.0, PaymentStatus.PENDING);
    }

    private OrderDTO createSampleOrderDTO() {
        return new OrderDTO(1L, 101L, 201L, "Model S", "MH12AB1234", "Tesla",
                PackageType.PREMIUM, "Wax", "Pending",
                LocalDate.now().plusDays(1), LocalDate.now().plusDays(2),
                "Mumbai", PaymentStatus.PENDING, 1500.0);
    }

    @Test
    void testCreateOrder() {
        Order order = createSampleOrder();
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderDTO dto = createSampleOrderDTO();
        OrderDTO result = orderService.createOrder(dto);

        assertNotNull(result);
        assertEquals("Tesla", result.getCarName());
        assertEquals(PackageType.PREMIUM, result.getPackageName());
    }

    @Test
    void testGetOrderById_Found() {
        Order order = createSampleOrder();
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        OrderDTO result = orderService.getOrderById(1L);

        assertNotNull(result);
        assertEquals("Tesla", result.getCarName());
    }

    @Test
    void testGetOrderById_NotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        OrderDTO result = orderService.getOrderById(1L);

        assertNull(result);
    }

    @Test
    void testGetAllOrders() {
        when(orderRepository.findAll()).thenReturn(List.of(createSampleOrder()));

        List<OrderDTO> result = orderService.getAllOrders();

        assertEquals(1, result.size());
        assertEquals("Tesla", result.get(0).getCarName());
    }

    @Test
    void testGetOrdersByCustomerId() {
        when(orderRepository.findByCustomerId(101L)).thenReturn(List.of(createSampleOrder()));

        List<OrderDTO> result = orderService.getOrdersByCustomerId(101L);

        assertEquals(1, result.size());
        assertEquals(101L, result.get(0).getCustomerId());
    }

    @Test
    void testGetOrdersByWasherId() {
        when(orderRepository.findByWasherId(201L)).thenReturn(List.of(createSampleOrder()));

        List<OrderDTO> result = orderService.getOrdersByWasherId(201L);

        assertEquals(1, result.size());
        assertEquals(201L, result.get(0).getWasherId());
    }

    @Test
    void testUpdateOrder_Found() {
        Order existing = createSampleOrder();
        Order updated = createSampleOrder();
        updated.setStatus("Accepted");

        OrderDTO dto = createSampleOrderDTO();
        dto.setStatus("Accepted");

        when(orderRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(orderRepository.save(any(Order.class))).thenReturn(updated);

        OrderDTO result = orderService.updateOrder(1L, dto);

        assertNotNull(result);
        assertEquals("Accepted", result.getStatus());
    }

    @Test
    void testUpdateOrder_NotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        OrderDTO result = orderService.updateOrder(1L, createSampleOrderDTO());

        assertNull(result);
    }

    @Test
    void testDeleteOrder() {
        doNothing().when(orderRepository).deleteById(1L);

        orderService.deleteOrder(1L);

        verify(orderRepository, times(1)).deleteById(1L);
    }

    @Test
    void testUpdateOrderStatus_Found() {
        Order order = createSampleOrder();
        order.setStatus("Accepted");

        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderDTO result = orderService.updateOrderStatus(1L, "Accepted");

        assertEquals("Accepted", result.getStatus());
    }

    @Test
    void testUpdateOrderStatus_NotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> orderService.updateOrderStatus(1L, "Accepted"));
    }

    @Test
    void testGetCurrentOrders() {
        when(orderRepository.findByCustomerIdAndStatus(101L, "Pending")).thenReturn(List.of(createSampleOrder()));

        List<OrderDTO> result = orderService.getCurrentOrders(101L);

        assertEquals(1, result.size());
        assertEquals("Pending", result.get(0).getStatus());
    }

    @Test
    void testGetPastOrders() {
        Order completedOrder = createSampleOrder();
        completedOrder.setStatus("Completed");

        when(orderRepository.findByCustomerIdAndStatusNot(101L, "Pending")).thenReturn(List.of(completedOrder));

        List<OrderDTO> result = orderService.getPastOrders(101L);

        assertEquals(1, result.size());
        assertEquals("Completed", result.get(0).getStatus());
    }
}
