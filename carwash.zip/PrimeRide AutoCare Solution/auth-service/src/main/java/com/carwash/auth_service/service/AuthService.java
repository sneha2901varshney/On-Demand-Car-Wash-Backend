package com.carwash.auth_service.service;



import com.carwash.auth_service.entity.User;
import com.carwash.auth_service.repository.UserRepository;
import com.carwash.auth_service.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;


import java.util.Optional;


@Service
public class AuthService {


    @Autowired
    private UserRepository userRepo;


    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;


    public String register(User user) {
        if (userRepo.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("User already exists");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user).getEmail() + " registered";
    }


    public String login(String email, String password) {
        Optional<User> user = userRepo.findByEmail(email);
        if (user.isEmpty()) throw new RuntimeException("User not found");


        if (!passwordEncoder.matches(password,user.get().getPassword())) {
            throw new RuntimeException("Invalid password");
        }


        return "Login SuccessFully!\nToken: "+jwtUtil.generateToken(email, user.get().getRole());
    }
}

