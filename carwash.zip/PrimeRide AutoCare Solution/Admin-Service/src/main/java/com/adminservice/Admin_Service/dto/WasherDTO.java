package com.adminservice.Admin_Service.dto;

import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class WasherDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;

    private String password;


}
