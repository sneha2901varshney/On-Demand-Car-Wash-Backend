package com.adminservice.Admin_Service.service;

import com.adminservice.Admin_Service.dto.AdminDTO;
import com.adminservice.Admin_Service.dto.CustomerDTO;
import com.adminservice.Admin_Service.dto.OrderDTO;
import com.adminservice.Admin_Service.dto.WasherDTO;

import java.util.List;

public interface AdminService {
    AdminDTO getAdminByEmail(String email);
    List<CustomerDTO> getAllCustomers();
    List<WasherDTO> fetchAllWashers();
    WasherDTO createWasher(WasherDTO washerDTO);
    void deleteWasher(Long id);

    // Customer
    void deleteCustomer(Long id);

    // Order
    List<OrderDTO> getAllOrders();
    OrderDTO updateOrderStatus(Long id, String status);
    void deleteOrder(Long id);



}
