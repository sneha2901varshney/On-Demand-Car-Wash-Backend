package com.adminservice.Admin_Service.service.impl;

import com.adminservice.Admin_Service.client.CustomerClient;
import com.adminservice.Admin_Service.client.OrderClient;
import com.adminservice.Admin_Service.client.WasherClient;
import com.adminservice.Admin_Service.dto.AdminDTO;
import com.adminservice.Admin_Service.dto.CustomerDTO;
import com.adminservice.Admin_Service.dto.WasherDTO;
import com.adminservice.Admin_Service.dto.OrderDTO;
import com.adminservice.Admin_Service.entity.Admin;
import com.adminservice.Admin_Service.repository.AdminRepository;
import com.adminservice.Admin_Service.service.AdminService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminRepository adminRepository;

//    private final PasswordEncoder passwordEncoder;

//    @Autowired
//    public AdminServiceImpl(AdminRepository adminRepository) {
//        this.adminRepository = adminRepository;
////        this.passwordEncoder = passwordEncoder;
//    }


    @Override
    public AdminDTO getAdminByEmail(String email) {
        Admin admin = adminRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException("Admin not found"));

        return new AdminDTO(admin.getId(), admin.getFullName(), admin.getEmail(), "********");
    }


//    FeignClients

    @Autowired
    private CustomerClient customerClient;

    @Autowired
    private OrderClient orderClient;

    public List<CustomerDTO> getAllCustomers() {

        log.info("Entering getAllCustomers method");

        List<CustomerDTO> customers = customerClient.fetchAllCustomers();
        log.info("Fetched {} customers", customers.size());
        log.debug("Customer details: {}", customers);

        log.info("Exiting getAllCustomers method");
        return customers;

    }


    @Autowired
    private WasherClient washerClient;

    @Override
    public List<WasherDTO> fetchAllWashers() {
        return washerClient.getAllWashers();
    }

    @Override
    public WasherDTO createWasher(WasherDTO washerDTO) {
        return washerClient.registerWasher(washerDTO);
    }

    @Override
    public void deleteWasher(Long id) {
        washerClient.deleteWasher(id);
    }

    @Override
    public void deleteCustomer(Long id) {
        customerClient.deleteCustomer(id);
    }

    @Override
    public List<OrderDTO> getAllOrders() {
        return orderClient.getAllOrders();
    }

    @Override
    public OrderDTO updateOrderStatus(Long id, String status) {
        return orderClient.updateOrderStatus(id, status);
    }

    @Override
    public void deleteOrder(Long id) {
        orderClient.deleteOrder(id);
    }



}
