package com.adminservice.Admin_Service.dto;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CustomerDTO {

    private Long id;
    private String fullName;
    private String email;


}
