package com.adminservice.Admin_Service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotNull(message = "Washer ID is required")
    private Long washerId;

    @NotBlank(message = "Car details are required")
    private String carDetails;

    @NotBlank(message = "Status is required")
    private String status;

    private LocalDateTime scheduledTime;


}
