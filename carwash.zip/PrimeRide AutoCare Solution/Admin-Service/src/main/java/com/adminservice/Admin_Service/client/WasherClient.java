package com.adminservice.Admin_Service.client;

import com.adminservice.Admin_Service.dto.WasherDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "WASHER-SERVICE")
public interface WasherClient {

    @GetMapping("/api/washers")
    List<WasherDTO> getAllWashers();

    @PostMapping("/api/washers/create")
    WasherDTO registerWasher(@RequestBody WasherDTO washerDTO);

    @DeleteMapping("/api/washers/{id}")
    void deleteWasher(@PathVariable Long id);
}
