package com.adminservice.Admin_Service.controller;

import com.adminservice.Admin_Service.dto.AdminDTO;
import com.adminservice.Admin_Service.dto.CustomerDTO;
import com.adminservice.Admin_Service.dto.OrderDTO;
import com.adminservice.Admin_Service.dto.WasherDTO;
import com.adminservice.Admin_Service.service.AdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Admin-related operations.
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private final AdminService adminService;

    @Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // Endpoint to register a new admin
//    @PostMapping("/register")
//    public ResponseEntity<AdminDTO> registerAdmin(@Valid @RequestBody AdminDTO adminDTO) {
//        AdminDTO saved = adminService.registerAdmin(adminDTO);
//        return ResponseEntity.ok(saved);
//    }

    // Endpoint to get admin details by email
    @GetMapping("/email/{email}")
    public ResponseEntity<AdminDTO> getAdminByEmail(@PathVariable String email) {
        return ResponseEntity.ok(adminService.getAdminByEmail(email));
    }


//    Customer using Feign
        @GetMapping("/customers")
        public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
            return ResponseEntity.ok(adminService.getAllCustomers());
        }

    @GetMapping("/washers")
    public ResponseEntity<List<WasherDTO>> fetchAllWashers() {
        return ResponseEntity.ok(adminService.fetchAllWashers());
    }

    @PostMapping("/washer")
    public ResponseEntity<WasherDTO> createWasher(@RequestBody @Valid WasherDTO washerDTO) {
        return ResponseEntity.ok(adminService.createWasher(washerDTO));
    }



    // DELETE washer
    @DeleteMapping("/washer/{id}")
    public ResponseEntity<Void> deleteWasher(@PathVariable Long id) {
        adminService.deleteWasher(id);
        return ResponseEntity.noContent().build();
    }

    // DELETE customer
    @DeleteMapping("/customer/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        adminService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }

    // GET all orders
    @GetMapping("/orders")
    public ResponseEntity<List<OrderDTO>> getAllOrders() {
        return ResponseEntity.ok(adminService.getAllOrders());
    }

    // UPDATE order status
    @PutMapping("/order/{id}/status")
    public ResponseEntity<OrderDTO> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String status
    ) {
        return ResponseEntity.ok(adminService.updateOrderStatus(id, status));
    }

    // DELETE order
    @DeleteMapping("/order/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        adminService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }




}
