package com.washerservice.Washer_Service.service.impl;

import com.washerservice.Washer_Service.client.OrderClient;
import com.washerservice.Washer_Service.client.ReviewClient;
import com.washerservice.Washer_Service.dto.OrderDTO;
import com.washerservice.Washer_Service.dto.ReviewDTO;
import com.washerservice.Washer_Service.dto.WasherDTO;
import com.washerservice.Washer_Service.entity.Washer;
import com.washerservice.Washer_Service.repository.WasherRepository;
import com.washerservice.Washer_Service.service.WasherService;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


//@Slf4j
@Service
public class WasherServiceImpl implements WasherService {

    private static final Logger log = LoggerFactory.getLogger(WasherServiceImpl.class);
    private final WasherRepository washerRepository;

    @Autowired
    public WasherServiceImpl(WasherRepository washerRepository) {
        this.washerRepository = washerRepository;
    }

    @Override
    public WasherDTO registerWasher(WasherDTO washerDTO) {
        Washer washer = new Washer();
        washer.setEmail(washerDTO.getEmail());
        washer.setName(washerDTO.getName());
        washer.setPassword(washerDTO.getPassword());
        washer.setPhone(washerDTO.getPhone());


        Washer saved = washerRepository.save(washer);
        return mapToDTO(saved);
    }

    @Override
    public List<WasherDTO> getAllWashers() {
        log.info("Entering getAllWashers method");
        List<WasherDTO> washer = washerRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());


        log.info("Fetched {} washers", washer.size());
        log.debug("Washer details: {}", washer);

        log.info("Exiting getAllWashers method");


        return washer;
    }

    @Override
    public WasherDTO getWasherById(Long id) {
        Washer washer = washerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Washer not found with id: " + id));
        return mapToDTO(washer);
    }

    @Override
    public WasherDTO updateWasher(Long id, WasherDTO washerDTO) {
        Washer washer = washerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Washer not found with id: " + id));

        washer.setEmail(washerDTO.getEmail());
        washer.setName(washerDTO.getName());
        washer.setPhone(washerDTO.getPhone());


        Washer updated = washerRepository.save(washer);
        return mapToDTO(updated);
    }

    @Override
    public void deleteWasher(Long id) {
        washerRepository.deleteById(id);
    }

    // Helper method
    private WasherDTO mapToDTO(Washer washer) {
        WasherDTO dto = new WasherDTO();
        dto.setId(washer.getId());
        dto.setEmail(washer.getEmail());
        dto.setName(washer.getName());
        dto.setPassword(washer.getPassword());
        dto.setPhone(washer.getPhone());

        return dto;
    }




    @Autowired
    private OrderClient orderClient;

    @Override
    public List<OrderDTO> getCurrentOrders(Long washerId) {
        return orderClient.getOrdersByWasher(washerId).stream()
                .filter(order -> order.getStatus().equalsIgnoreCase("pending") || order.getStatus().equalsIgnoreCase("in-progress"))
                .collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> getPastOrders(Long washerId) {
        return orderClient.getOrdersByWasher(washerId).stream()
                .filter(order -> order.getStatus().equalsIgnoreCase("completed") || order.getStatus().equalsIgnoreCase("cancelled"))
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO acceptOrder(Long orderId) {
        return orderClient.updateOrderStatus(orderId, "accepted");
    }

    @Override
    public OrderDTO declineOrder(Long orderId) {
        return orderClient.updateOrderStatus(orderId, "declined");
    }

    @Autowired
    private ReviewClient reviewClient;

    @Override
    public List<ReviewDTO> getReviewsForWasher(Long washerId) {
        return reviewClient.getReviewsByWasherId(washerId);
    }


}
