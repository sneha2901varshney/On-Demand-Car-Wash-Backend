package com.washerservice.Washer_Service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InvoiceDTO {

    @NotNull(message = "Washer ID is required")
    private Long washerId;

    @NotNull(message = "Order ID is required")
    private Long orderId;

    @NotBlank(message = "Package name is required")
    private String packageName;

    private String addOns;
    private String imageUrl;


}
