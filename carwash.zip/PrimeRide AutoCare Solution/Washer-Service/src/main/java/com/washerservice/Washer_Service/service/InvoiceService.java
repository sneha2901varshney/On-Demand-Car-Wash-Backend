package com.washerservice.Washer_Service.service;

import com.washerservice.Washer_Service.dto.InvoiceDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface InvoiceService {
    InvoiceDTO generateInvoice(InvoiceDTO invoiceDTO);

    List<InvoiceDTO> getInvoicesByWasherId(Long washerId);

    List<InvoiceDTO> getInvoicesByOrderId(Long orderId);
    InvoiceDTO generateInvoiceWithImage(Long washerId, Long orderId, String packageName, String addOns, MultipartFile imageFile);

}
