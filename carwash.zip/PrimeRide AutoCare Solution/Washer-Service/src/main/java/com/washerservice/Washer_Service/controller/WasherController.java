package com.washerservice.Washer_Service.controller;

import com.washerservice.Washer_Service.dto.OrderDTO;
import com.washerservice.Washer_Service.dto.ReviewDTO;
import com.washerservice.Washer_Service.dto.WasherDTO;
import com.washerservice.Washer_Service.service.WasherService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/washers")
public class WasherController {

    @Autowired
    private WasherService washerService;

    // ✅ Register Washer
    @PostMapping("/create")
    public ResponseEntity<WasherDTO> createWasher(@Valid @RequestBody WasherDTO washerDTO) {
        return ResponseEntity.ok(washerService.registerWasher(washerDTO));
    }
    

    // ✅ Get all washers
    @GetMapping
    public ResponseEntity<List<WasherDTO>> getAll() {
        return ResponseEntity.ok(washerService.getAllWashers());
    }

    // ✅ Get washer by ID
    @GetMapping("/{id}")
    public ResponseEntity<WasherDTO> getById(@Valid @PathVariable Long id) {
        return ResponseEntity.ok(washerService.getWasherById(id));
    }

    // ✅ Update washer
    @PutMapping("/{id}")
    public ResponseEntity<WasherDTO> update(@Valid @PathVariable Long id, @Valid @RequestBody WasherDTO washerDTO) {
        return ResponseEntity.ok(washerService.updateWasher(id, washerDTO));
    }

    // ✅ Delete washer
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@Valid @PathVariable Long id) {
        washerService.deleteWasher(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ Get current orders
    @GetMapping("/{washerId}/orders/current")
    public ResponseEntity<List<OrderDTO>> getCurrentOrders(@Valid @PathVariable Long washerId) {
        return ResponseEntity.ok(washerService.getCurrentOrders(washerId));
    }

    // ✅ Get past orders
    @GetMapping("/{washerId}/orders/past")
    public ResponseEntity<List<OrderDTO>> getPastOrders(@Valid @PathVariable Long washerId) {
        return ResponseEntity.ok(washerService.getPastOrders(washerId));
    }

    // ✅ Accept an order
    @PutMapping("/orders/{orderId}/accept")
    public ResponseEntity<OrderDTO> acceptOrder(@Valid @PathVariable Long orderId) {
        return ResponseEntity.ok(washerService.acceptOrder(orderId));
    }

    // ✅ Decline an order
    @PutMapping("/orders/{orderId}/decline")
    public ResponseEntity<OrderDTO> declineOrder(@Valid @PathVariable Long orderId) {
        return ResponseEntity.ok(washerService.declineOrder(orderId));
    }

    @GetMapping("/{washerId}/reviews")
    public ResponseEntity<List<ReviewDTO>> getWasherReviews(@PathVariable Long washerId) {
        return ResponseEntity.ok(washerService.getReviewsForWasher(washerId));
    }

}
