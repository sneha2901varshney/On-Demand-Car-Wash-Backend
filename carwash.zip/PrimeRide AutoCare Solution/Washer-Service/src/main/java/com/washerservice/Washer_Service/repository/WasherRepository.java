package com.washerservice.Washer_Service.repository;

import com.washerservice.Washer_Service.entity.Washer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WasherRepository extends JpaRepository<Washer, Long> {
    Optional<Washer> findByEmail(String email);

    boolean existsByEmail(String email);
}
