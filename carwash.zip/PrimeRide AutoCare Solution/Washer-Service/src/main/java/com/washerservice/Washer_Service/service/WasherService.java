package com.washerservice.Washer_Service.service;

import com.washerservice.Washer_Service.dto.OrderDTO;
import com.washerservice.Washer_Service.dto.ReviewDTO;
import com.washerservice.Washer_Service.dto.WasherDTO;

import java.util.List;

public interface WasherService {
    WasherDTO registerWasher(WasherDTO washerDTO);
    List<WasherDTO> getAllWashers();
    WasherDTO getWasherById(Long id);
    WasherDTO updateWasher(Long id, WasherDTO washerDTO);
    void deleteWasher(Long id);

    // WasherService.java
    List<OrderDTO> getCurrentOrders(Long washerId);
    List<OrderDTO> getPastOrders(Long washerId);

    OrderDTO acceptOrder(Long orderId);

    OrderDTO declineOrder(Long orderId);
    List<ReviewDTO> getReviewsForWasher(Long washerId);


}
