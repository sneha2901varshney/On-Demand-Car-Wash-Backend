package com.washerservice.Washer_Service.entity;

import jakarta.persistence.*;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "invoices")
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long washerId;

    private Long orderId;

    private String packageName;

    private String addOns;

    private String imageUrl;


}
