package com.washerservice.Washer_Service.service.impl;

import com.washerservice.Washer_Service.client.OrderClient;
import com.washerservice.Washer_Service.dto.InvoiceDTO;
import com.washerservice.Washer_Service.entity.Invoice;
import com.washerservice.Washer_Service.repository.InvoiceRepository;
import com.washerservice.Washer_Service.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InvoiceServiceImpl implements InvoiceService {
    @Autowired
    private final InvoiceRepository invoiceRepository;

    @Autowired
    OrderClient orderClient;

    @Autowired
    public InvoiceServiceImpl(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public InvoiceDTO generateInvoice(InvoiceDTO invoiceDTO) {
        Invoice invoice = new Invoice();
        invoice.setOrderId(invoiceDTO.getOrderId());
        invoice.setWasherId(invoiceDTO.getWasherId());
        invoice.setPackageName(invoiceDTO.getPackageName());
        invoice.setAddOns(invoiceDTO.getAddOns());
        // Mark order as completed after invoice is generated

        orderClient.updateOrderStatus(invoiceDTO.getOrderId(), "COMPLETED");


        Invoice saved = invoiceRepository.save(invoice);
        return mapToDTO(saved);
    }

    @Override
    public InvoiceDTO generateInvoiceWithImage(Long washerId, Long orderId, String packageName, String addOns, MultipartFile imageFile) {
        try {
            // Store image in file system
            String fileName = "invoice_" + orderId + "_" + System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
            String uploadDir = "uploads/invoices/";
            File uploadPath = new File(uploadDir);
            if (!uploadPath.exists()) uploadPath.mkdirs();

            String filePath = uploadDir + fileName;
            File dest = new File(filePath);
            imageFile.transferTo(dest);

            // Create and save invoice
            Invoice invoice = new Invoice();
            invoice.setWasherId(washerId);
            invoice.setOrderId(orderId);
            invoice.setPackageName(packageName);
            invoice.setAddOns(addOns);
            invoice.setImageUrl(filePath); // store path

            orderClient.updateOrderStatus(orderId, "COMPLETED");

            Invoice saved = invoiceRepository.save(invoice);
            return mapToDTO(saved);
        } catch (Exception e) {
            throw new RuntimeException("Failed to upload image and create invoice", e);
        }
    }


    @Override
    public List<InvoiceDTO> getInvoicesByWasherId(Long washerId) {
        return invoiceRepository.findByWasherId(washerId)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Override
    public List<InvoiceDTO> getInvoicesByOrderId(Long orderId) {
        return invoiceRepository.findByOrderId(orderId)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }



    private InvoiceDTO mapToDTO(Invoice invoice) {
        InvoiceDTO dto = new InvoiceDTO();
        dto.setOrderId(invoice.getOrderId());
        dto.setWasherId(invoice.getWasherId());
        dto.setPackageName(invoice.getPackageName());
        dto.setAddOns(invoice.getAddOns());
        dto.setImageUrl(invoice.getImageUrl());
        return dto;
    }


}
