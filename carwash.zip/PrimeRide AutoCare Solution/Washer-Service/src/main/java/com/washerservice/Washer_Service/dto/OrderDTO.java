package com.washerservice.Washer_Service.dto;

import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;
    private Long customerId;
    private Long washerId;
    private String carModel;
    private String washPackage;
    private String addons;
    private String status; // e.g. NEW, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED
    private String location;
    private LocalDateTime scheduledTime;


}
