package com.washerservice.Washer_Service.dto;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ReviewDTO {
    private Long id;
    private Long washerId;
    private Long customerId;
    private Long orderId;
    private int rating;
    private String comment;
}
