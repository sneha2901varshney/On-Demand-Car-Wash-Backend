package com.washerservice.Washer_Service.client;

import com.washerservice.Washer_Service.dto.OrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "ORDER-SERVICE")
public interface OrderClient {

    @GetMapping("/api/orders/washer/{washerId}")
    List<OrderDTO> getOrdersByWasher(@PathVariable Long washerId);

    @PutMapping("/api/orders/status/{id}")
    OrderDTO updateOrderStatus(@PathVariable Long id, @RequestParam String status);

    @PutMapping("/orders/{orderId}/complete")
    void markOrderAsCompleted(@PathVariable Long orderId);


}
