package com.washerservice.Washer_Service.controller;

import com.washerservice.Washer_Service.dto.InvoiceDTO;
import com.washerservice.Washer_Service.service.InvoiceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    @Autowired
    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    /**
     * Generate invoice for an order
     */
    @PostMapping
    public ResponseEntity<InvoiceDTO> createInvoice(@Valid @RequestBody InvoiceDTO invoiceDTO) {
        InvoiceDTO savedInvoice = invoiceService.generateInvoice(invoiceDTO);
        return ResponseEntity.ok(savedInvoice);
    }

    /**
     * Get all invoices for a specific washer
     */
    @GetMapping("/washer/{washerId}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByWasher(@Valid @PathVariable Long washerId) {
        List<InvoiceDTO> invoices = invoiceService.getInvoicesByWasherId(washerId);
        return ResponseEntity.ok(invoices);
    }

    /**
     * Get all invoices for a specific order
     */
    @GetMapping("/order/{orderId}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByOrder(@Valid @PathVariable Long orderId) {
        List<InvoiceDTO> invoices = invoiceService.getInvoicesByOrderId(orderId);
        return ResponseEntity.ok(invoices);
    }

    @PostMapping("/upload")
    public ResponseEntity<InvoiceDTO> uploadInvoiceWithImage(
            @RequestParam("washerId") Long washerId,
            @RequestParam("orderId") Long orderId,
            @RequestParam("packageName") String packageName,
            @RequestParam(value = "addOns", required = false) String addOns,
            @RequestParam("image") MultipartFile imageFile) {

        InvoiceDTO invoiceDTO = invoiceService.generateInvoiceWithImage(washerId, orderId, packageName, addOns, imageFile);
        return ResponseEntity.ok(invoiceDTO);
    }



}
