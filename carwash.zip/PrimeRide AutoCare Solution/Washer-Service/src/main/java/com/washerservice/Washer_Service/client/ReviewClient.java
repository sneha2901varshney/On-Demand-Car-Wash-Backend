package com.washerservice.Washer_Service.client;

import com.washerservice.Washer_Service.dto.ReviewDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface ReviewClient {

    @GetMapping("/reviews/washer/{washerId}")
    List<ReviewDTO> getReviewsByWasherId(@PathVariable Long washerId);
}
