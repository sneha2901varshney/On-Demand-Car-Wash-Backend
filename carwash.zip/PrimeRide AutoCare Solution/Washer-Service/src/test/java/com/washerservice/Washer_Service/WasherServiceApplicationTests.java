package com.washerservice.Washer_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasherServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
