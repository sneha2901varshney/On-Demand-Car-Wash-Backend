package com.washerservice.Washer_Service.service;

import com.washerservice.Washer_Service.client.OrderClient;
import com.washerservice.Washer_Service.client.ReviewClient;
import com.washerservice.Washer_Service.dto.OrderDTO;
import com.washerservice.Washer_Service.dto.ReviewDTO;
import com.washerservice.Washer_Service.dto.WasherDTO;
import com.washerservice.Washer_Service.entity.Washer;
import com.washerservice.Washer_Service.repository.WasherRepository;
import com.washerservice.Washer_Service.service.impl.WasherServiceImpl;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class WasherServiceImplTest {

    @Mock
    private WasherRepository washerRepository;

    @Mock
    private OrderClient orderClient;

    @Mock
    private ReviewClient reviewClient;

    private WasherServiceImpl washerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        washerService = new WasherServiceImpl(washerRepository);
        ReflectionTestUtils.setField(washerService, "orderClient", orderClient);
        ReflectionTestUtils.setField(washerService, "reviewClient", reviewClient);
    }

    @Test
    void testRegisterWasher() {
        WasherDTO dto = new WasherDTO(null, "John Doe", "john@example.com", "1234567890", "secret");
        Washer saved = new Washer(1L, "john@example.com", "secret", "John Doe", "1234567890");

        when(washerRepository.save(any(Washer.class))).thenReturn(saved);

        WasherDTO result = washerService.registerWasher(dto);

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    void testGetAllWashers() {
        Washer washer = new Washer(1L, "john@example.com", "secret", "John Doe", "1234567890");
        when(washerRepository.findAll()).thenReturn(List.of(washer));

        List<WasherDTO> result = washerService.getAllWashers();

        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).getName());
    }

    @Test
    void testGetWasherById_Found() {
        Washer washer = new Washer(1L, "john@example.com", "secret", "John Doe", "1234567890");
        when(washerRepository.findById(1L)).thenReturn(Optional.of(washer));

        WasherDTO result = washerService.getWasherById(1L);

        assertEquals("John Doe", result.getName());
    }

    @Test
    void testGetWasherById_NotFound() {
        when(washerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> washerService.getWasherById(1L));
    }

    @Test
    void testUpdateWasher() {
        Washer existing = new Washer(1L, "old@example.com", "secret", "Old Name", "1111111111");
        Washer updated = new Washer(1L, "new@example.com", "secret", "New Name", "9999999999");

        WasherDTO dto = new WasherDTO(null, "New Name", "new@example.com", "9999999999", "secret");

        when(washerRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(washerRepository.save(any(Washer.class))).thenReturn(updated);

        WasherDTO result = washerService.updateWasher(1L, dto);

        assertEquals("New Name", result.getName());
        assertEquals("new@example.com", result.getEmail());
    }

    @Test
    void testDeleteWasher() {
        doNothing().when(washerRepository).deleteById(1L);

        washerService.deleteWasher(1L);

        verify(washerRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetCurrentOrders() {
        List<OrderDTO> orders = List.of(
                new OrderDTO(1L, 2L, 1L, "Model X", "Premium", "Wax", "pending", "NY", LocalDateTime.now()),
                new OrderDTO(2L, 2L, 1L, "Model Y", "Basic", "", "in-progress", "NY", LocalDateTime.now()),
                new OrderDTO(3L, 2L, 1L, "Model Z", "Deluxe", "", "completed", "NY", LocalDateTime.now())
        );

        when(orderClient.getOrdersByWasher(1L)).thenReturn(orders);

        List<OrderDTO> result = washerService.getCurrentOrders(1L);

        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(o ->
                o.getStatus().equalsIgnoreCase("pending") || o.getStatus().equalsIgnoreCase("in-progress")));
    }

    @Test
    void testGetPastOrders() {
        List<OrderDTO> orders = List.of(
                new OrderDTO(1L, 2L, 1L, "Model X", "Premium", "Wax", "completed", "NY", LocalDateTime.now()),
                new OrderDTO(2L, 2L, 1L, "Model Y", "Basic", "", "cancelled", "NY", LocalDateTime.now()),
                new OrderDTO(3L, 2L, 1L, "Model Z", "Deluxe", "", "pending", "NY", LocalDateTime.now())
        );

        when(orderClient.getOrdersByWasher(1L)).thenReturn(orders);

        List<OrderDTO> result = washerService.getPastOrders(1L);

        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(o ->
                o.getStatus().equalsIgnoreCase("completed") || o.getStatus().equalsIgnoreCase("cancelled")));
    }

    @Test
    void testAcceptOrder() {
        OrderDTO acceptedOrder = new OrderDTO(1L, 2L, 1L, "Model X", "Premium", "Wax", "accepted", "NY", LocalDateTime.now());
        when(orderClient.updateOrderStatus(1L, "accepted")).thenReturn(acceptedOrder);

        OrderDTO result = washerService.acceptOrder(1L);

        assertNotNull(result);
        assertEquals("accepted", result.getStatus());
    }

    @Test
    void testDeclineOrder() {
        OrderDTO declinedOrder = new OrderDTO(1L, 2L, 1L, "Model X", "Premium", "Wax", "declined", "NY", LocalDateTime.now());
        when(orderClient.updateOrderStatus(1L, "declined")).thenReturn(declinedOrder);

        OrderDTO result = washerService.declineOrder(1L);

        assertNotNull(result);
        assertEquals("declined", result.getStatus());
    }

    @Test
    void testGetReviewsForWasher() {
        ReviewDTO review = new ReviewDTO(1L, 1L, 2L, 3L, 5, "Excellent service!");
        when(reviewClient.getReviewsByWasherId(1L)).thenReturn(List.of(review));

        List<ReviewDTO> result = washerService.getReviewsForWasher(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Excellent service!", result.get(0).getComment());
    }
}
